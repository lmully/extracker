import plotly.graph_objects as go
import plotly.express as px
import pandas as pd
from datetime import datetime, timedelta
import calendar

def create_progress_charts(exercise_data, targets, progress):
    if not exercise_data:  # Handle empty data case
        empty_fig = go.Figure()
        empty_fig.update_layout(
            title='No exercise data available',
            annotations=[{
                'text': 'Start adding your daily exercises to see progress charts',
                'xref': 'paper',
                'yref': 'paper',
                'showarrow': False,
                'font': {'size': 14}
            }]
        )
        return {'monthly': empty_fig, 'timeline': empty_fig, 'max_timeline': empty_fig}

    # Create summary DataFrame with total and max values
    df = pd.DataFrame([{
        'date': datetime.strptime(record['date'], '%Y-%m-%d'),
        'pushups_total': record['pushups_total'],
        'situps_total': record['situps_total'],
        'squats_total': record['squats_total'],
        'pushups_max': record['pushups_max'],
        'situps_max': record['situps_max'],
        'squats_max': record['squats_max']
    } for record in exercise_data])

    # Progress bars for different timeframes
    figures = {}

    # Monthly progress
    monthly_fig = go.Figure()
    exercise_map = {
        'pushups': 'Push-ups',
        'situps': 'Sit-ups',
        'squats': 'Squats'
    }

    for exercise in ['pushups', 'situps', 'squats']:
        current_progress = progress['monthly'][exercise]
        target = targets['monthly'][exercise]
        percentage = (current_progress / target * 100) if target > 0 else 0

        monthly_fig.add_trace(go.Bar(
            name=exercise_map[exercise],
            x=['Progress'],
            y=[current_progress],
            text=[f"{percentage:.1f}%"],
            textposition='auto',
        ))
        monthly_fig.add_trace(go.Bar(
            name=f'{exercise_map[exercise]} Target',
            x=['Target'],
            y=[target],
            text=[target],
            textposition='auto',
        ))

    monthly_fig.update_layout(
        title='Monthly Progress vs Targets',
        barmode='group',
        height=400
    )
    figures['monthly'] = monthly_fig

    # Total reps timeline
    timeline_fig = go.Figure()
    for exercise in ['pushups', 'situps', 'squats']:
        timeline_fig.add_trace(go.Scatter(
            x=df['date'],
            y=df[f'{exercise}_total'],
            name=f"{exercise_map[exercise]} Total",
            mode='lines+markers'
        ))

    timeline_fig.update_layout(
        title='Daily Exercise Totals Timeline',
        xaxis_title='Date',
        yaxis_title='Total Repetitions',
        height=400
    )
    figures['timeline'] = timeline_fig

    # Max sets timeline
    max_timeline_fig = go.Figure()
    for exercise in ['pushups', 'situps', 'squats']:
        max_timeline_fig.add_trace(go.Scatter(
            x=df['date'],
            y=df[f'{exercise}_max'],
            name=f"{exercise_map[exercise]} Max Set",
            mode='lines+markers'
        ))

    max_timeline_fig.update_layout(
        title='Max Sets Timeline',
        xaxis_title='Date',
        yaxis_title='Max Repetitions in Set',
        height=400
    )
    figures['max_timeline'] = max_timeline_fig

    return figures

def create_summary_cards(progress, targets):
    cards = {}
    timeframes = ['monthly', 'quarterly', 'yearly']
    exercises = ['pushups', 'situps', 'squats']

    for timeframe in timeframes:
        cards[timeframe] = {}
        for exercise in exercises:
            current = progress[timeframe][exercise]
            target = targets[timeframe][exercise]
            percentage = (current / target * 100) if target > 0 else 0
            cards[timeframe][exercise] = {
                'current': current,
                'target': target,
                'percentage': percentage
            }

    return cards

def create_calendar_heatmap(exercise_data):
    """Create an interactive calendar heatmap showing workout consistency"""
    if not exercise_data:
        empty_fig = go.Figure()
        empty_fig.update_layout(
            title='No exercise data available for heatmap',
            annotations=[{
                'text': 'Start adding your daily exercises to see the heatmap',
                'xref': 'paper',
                'yref': 'paper',
                'showarrow': False,
                'font': {'size': 14}
            }]
        )
        return empty_fig

    # Convert exercise data to DataFrame
    df = pd.DataFrame([{
        'date': datetime.strptime(record['date'], '%Y-%m-%d'),
        'total_exercises': (
            record['pushups_total'] +
            record['situps_total'] +
            record['squats_total']
        ),
        'pushups': record['pushups_total'],
        'situps': record['situps_total'],
        'squats': record['squats_total']
    } for record in exercise_data])

    # Get the date range
    min_date = df['date'].min()
    max_date = df['date'].max()

    # Create a complete date range including missing dates
    all_dates = pd.date_range(start=min_date, end=max_date, freq='D')
    df_complete = pd.DataFrame({'date': all_dates})
    df = pd.merge(df_complete, df, on='date', how='left')
    df = df.fillna(0)

    # Extract components for heatmap
    df['weekday'] = df['date'].dt.weekday
    df['week'] = df['date'].dt.strftime('%Y-%V')

    # Create hover text
    df['hover_text'] = df.apply(lambda x: (
        f"Date: {x['date'].strftime('%Y-%m-%d')}<br>"
        f"Total Exercises: {int(x['total_exercises'])}<br>"
        f"Push-ups: {int(x['pushups'])}<br>"
        f"Sit-ups: {int(x['situps'])}<br>"
        f"Squats: {int(x['squats'])}"
    ), axis=1)

    # Create the heatmap
    fig = go.Figure(data=go.Heatmap(
        x=df['week'],
        y=df['weekday'],
        z=df['total_exercises'],
        text=df['hover_text'],
        hoveringmode='closest',
        hoverinfo='text',
        colorscale='YlOrRd',
        showscale=True,
        colorbar=dict(
            title='Total Exercises'
        )
    ))

    # Customize layout
    fig.update_layout(
        title='Workout Consistency Calendar',
        xaxis_title='Week',
        yaxis=dict(
            ticktext=['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
            tickvals=list(range(7)),
            autorange="reversed"
        ),
        height=400
    )

    return fig