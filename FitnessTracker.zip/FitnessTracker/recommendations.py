from datetime import datetime, timedelta
import numpy as np

class WorkoutRecommender:
    def __init__(self, data_manager):
        self.data_manager = data_manager
        
    def _calculate_trends(self, exercise_history, exercise_type):
        """Calculate trends for a specific exercise type"""
        if not exercise_history:
            return {
                'progress_rate': 0,
                'consistency': 0,
                'max_improvement': 0
            }
            
        # Extract max sets for the exercise type
        max_sets = [record[f'{exercise_type}_max'] for record in exercise_history]
        
        # Calculate progress rate (average improvement between sessions)
        if len(max_sets) > 1:
            progress_rate = (max_sets[-1] - max_sets[0]) / len(max_sets)
        else:
            progress_rate = 0
            
        # Calculate consistency (workouts per week)
        dates = [datetime.strptime(record['date'], '%Y-%m-%d') for record in exercise_history]
        if len(dates) > 1:
            date_range = (max(dates) - min(dates)).days / 7  # weeks
            consistency = len(dates) / date_range if date_range > 0 else 1
        else:
            consistency = 1
            
        # Calculate max improvement between consecutive sessions
        max_improvement = max([max_sets[i] - max_sets[i-1] for i in range(1, len(max_sets))], default=0)
            
        return {
            'progress_rate': progress_rate,
            'consistency': consistency,
            'max_improvement': max_improvement
        }
        
    def _generate_exercise_recommendation(self, current_max, trend_data, target):
        """Generate specific recommendations for an exercise"""
        progress_rate = trend_data['progress_rate']
        consistency = trend_data['consistency']
        max_improvement = trend_data['max_improvement']
        
        # Base recommendation on current performance and trends
        if progress_rate <= 0:
            # If no progress or declining
            sets = 3
            reps_per_set = int(current_max * 0.8)  # Reduce intensity to build back up
            message = "Focus on form and gradual improvement"
        else:
            # Calculate challenging but achievable targets
            if consistency >= 3:  # Consistent training (3+ times per week)
                sets = 4
                reps_per_set = int(min(current_max * 1.1, current_max + max_improvement))
                message = "Great consistency! Push for new records"
            else:
                sets = 3
                reps_per_set = int(current_max)
                message = "Try to increase workout frequency for better results"
                
        return {
            'sets': sets,
            'reps_per_set': max(1, reps_per_set),  # Ensure at least 1 rep
            'message': message
        }
        
    def get_recommendations(self):
        """Generate personalized workout recommendations based on progress"""
        exercise_history = self.data_manager.get_exercise_history()
        targets = self.data_manager.get_targets()
        progress = self.data_manager.get_progress()
        
        recommendations = {}
        for exercise in ['pushups', 'situps', 'squats']:
            # Calculate trends
            trends = self._calculate_trends(exercise_history, exercise)
            
            # Get current max
            current_max = progress['max_sets'][exercise]
            target = targets['overall'][exercise]
            
            # Generate specific recommendations
            recommendations[exercise] = self._generate_exercise_recommendation(
                current_max, trends, target
            )
            
        return recommendations
