from datetime import datetime

def validate_exercise_input(pushups_sets, situps_sets, squats_sets):
    """Validate exercise input values"""
    errors = []

    for i, pushups in enumerate(pushups_sets):
        if not isinstance(pushups, (int, float)) or pushups < 0:
            errors.append(f"Push-ups Set {i+1} must be a positive number")

    for i, situps in enumerate(situps_sets):
        if not isinstance(situps, (int, float)) or situps < 0:
            errors.append(f"Sit-ups Set {i+1} must be a positive number")

    for i, squats in enumerate(squats_sets):
        if not isinstance(squats, (int, float)) or squats < 0:
            errors.append(f"Squats Set {i+1} must be a positive number")

    return errors

def validate_targets(targets):
    """Validate target values"""
    errors = []
    required_timeframes = ['overall', 'monthly', 'quarterly', 'yearly']
    required_exercises = ['pushups', 'situps', 'squats']

    for timeframe in required_timeframes:
        if timeframe not in targets:
            errors.append(f"Missing {timeframe} targets")
            continue

        for exercise in required_exercises:
            if exercise not in targets[timeframe]:
                errors.append(f"Missing {exercise} target for {timeframe}")
                continue

            if not isinstance(targets[timeframe][exercise], (int, float)) or targets[timeframe][exercise] < 0:
                errors.append(f"Invalid {exercise} target for {timeframe}")

    return errors