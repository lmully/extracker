import streamlit as st
import pandas as pd
from datetime import datetime
from data_manager import DataManager
from visualization import create_progress_charts, create_summary_cards, create_calendar_heatmap
from utils import validate_exercise_input, validate_targets
from recommendations import WorkoutRecommender

# Initialize data manager and recommender
data_manager = DataManager()
recommender = WorkoutRecommender(data_manager)

# Set page config
st.set_page_config(
    page_title="Exercise Tracker",
    page_icon="🏃‍♂️",
    layout="wide"
)

# Main title
st.title("🏃‍♂️ Exercise Tracker")

# Check and display active challenge
def display_challenge():
    challenge = data_manager.get_active_challenge()
    if not challenge:
        challenge = data_manager.create_weekly_challenge()

    if challenge:
        st.sidebar.markdown("---")
        st.sidebar.header("🎮 Weekly Challenge")

        # Calculate days remaining
        days_remaining = (challenge.end_date - datetime.now().date()).days

        # Check completion status
        is_completed = data_manager.check_challenge_completion()

        if is_completed:
            st.sidebar.success(f"🎉 Challenge Completed!\n\n{challenge.description}\n\nPoints earned: {challenge.reward_points}")
        else:
            st.sidebar.info(
                f"**Active Challenge:**\n\n"
                f"{challenge.description}\n\n"
                f"Days remaining: {days_remaining}\n\n"
                f"Reward: {challenge.reward_points} points"
            )

            # Show progress bar
            progress = data_manager.get_progress()
            if challenge.challenge_type != 'combined':
                current = progress['monthly'][challenge.challenge_type]
            else:
                current = (
                    progress['monthly']['pushups'] +
                    progress['monthly']['situps'] +
                    progress['monthly']['squats']
                )

            progress_percentage = min(100, (current / challenge.target_value) * 100)
            st.sidebar.progress(progress_percentage / 100)  # Convert percentage to decimal
            st.sidebar.text(f"Progress: {current}/{challenge.target_value}")

display_challenge()

# Sidebar navigation
page = st.sidebar.radio("Navigation", ["Daily Input", "Targets", "Progress", "History", "Recommendations"])

if page == "Recommendations":
    st.header("Personalized Workout Recommendations")

    recommendations = recommender.get_recommendations()

    # Display recommendations for each exercise type
    col1, col2, col3 = st.columns(3)

    with col1:
        st.subheader("🔄 Push-ups")
        rec = recommendations['pushups']
        st.info(
            f"**Recommended Workout:**\n\n"
            f"- Sets: {rec['sets']}\n"
            f"- Reps per set: {rec['reps_per_set']}\n\n"
            f"_{rec['message']}_"
        )

    with col2:
        st.subheader("🔄 Sit-ups")
        rec = recommendations['situps']
        st.info(
            f"**Recommended Workout:**\n\n"
            f"- Sets: {rec['sets']}\n"
            f"- Reps per set: {rec['reps_per_set']}\n\n"
            f"_{rec['message']}_"
        )

    with col3:
        st.subheader("🔄 Squats")
        rec = recommendations['squats']
        st.info(
            f"**Recommended Workout:**\n\n"
            f"- Sets: {rec['sets']}\n"
            f"- Reps per set: {rec['reps_per_set']}\n\n"
            f"_{rec['message']}_"
        )

    st.markdown("""
    ---
    ### How recommendations work:
    - Based on your progress rate and consistency
    - Adapts to your current performance level
    - Suggests achievable but challenging goals
    - Updates as you log more workouts
    """)

elif page == "Daily Input":
    st.header("Daily Exercise Input")

    with st.form("exercise_input"):
        num_sets = st.number_input("Number of Sets", min_value=1, max_value=10, value=3)

        pushups_sets = []
        situps_sets = []
        squats_sets = []

        cols = st.columns(num_sets)
        for i in range(num_sets):
            with cols[i]:
                st.write(f"Set {i+1}")
                pushups_sets.append(st.number_input(f"Push-ups Set {i+1}", min_value=0, value=0, key=f"pushups_{i}"))
                situps_sets.append(st.number_input(f"Sit-ups Set {i+1}", min_value=0, value=0, key=f"situps_{i}"))
                squats_sets.append(st.number_input(f"Squats Set {i+1}", min_value=0, value=0, key=f"squats_{i}"))

        submitted = st.form_submit_button("Save Exercise Data")

        if submitted:
            errors = validate_exercise_input(pushups_sets, situps_sets, squats_sets)
            if errors:
                for error in errors:
                    st.error(error)
            else:
                data_manager.save_daily_exercise(pushups_sets, situps_sets, squats_sets)
                st.success("Exercise data saved successfully!")

elif page == "Targets":
    st.header("Set Exercise Targets")

    targets = data_manager.get_targets()

    with st.form("target_setting"):
        st.subheader("Overall Targets")
        overall_pushups = st.number_input("Push-ups Overall Target", value=targets['overall']['pushups'])
        overall_situps = st.number_input("Sit-ups Overall Target", value=targets['overall']['situps'])
        overall_squats = st.number_input("Squats Overall Target", value=targets['overall']['squats'])

        st.subheader("Monthly Targets")
        monthly_pushups = st.number_input("Push-ups Monthly Target", value=targets['monthly']['pushups'])
        monthly_situps = st.number_input("Sit-ups Monthly Target", value=targets['monthly']['situps'])
        monthly_squats = st.number_input("Squats Monthly Target", value=targets['monthly']['squats'])

        st.subheader("Quarterly Targets")
        quarterly_pushups = st.number_input("Push-ups Quarterly Target", value=targets['quarterly']['pushups'])
        quarterly_situps = st.number_input("Sit-ups Quarterly Target", value=targets['quarterly']['situps'])
        quarterly_squats = st.number_input("Squats Quarterly Target", value=targets['quarterly']['squats'])

        st.subheader("Yearly Targets")
        yearly_pushups = st.number_input("Push-ups Yearly Target", value=targets['yearly']['pushups'])
        yearly_situps = st.number_input("Sit-ups Yearly Target", value=targets['yearly']['situps'])
        yearly_squats = st.number_input("Squats Yearly Target", value=targets['yearly']['squats'])

        submitted = st.form_submit_button("Save Targets")

        if submitted:
            new_targets = {
                'overall': {
                    'pushups': overall_pushups,
                    'situps': overall_situps,
                    'squats': overall_squats
                },
                'monthly': {
                    'pushups': monthly_pushups,
                    'situps': monthly_situps,
                    'squats': monthly_squats
                },
                'quarterly': {
                    'pushups': quarterly_pushups,
                    'situps': quarterly_situps,
                    'squats': quarterly_squats
                },
                'yearly': {
                    'pushups': yearly_pushups,
                    'situps': yearly_situps,
                    'squats': yearly_squats
                }
            }

            errors = validate_targets(new_targets)
            if errors:
                for error in errors:
                    st.error(error)
            else:
                data_manager.save_targets(new_targets)
                st.success("Targets updated successfully!")

elif page == "Progress":
    st.header("Progress Dashboard")

    exercise_data = data_manager.get_exercise_history()
    targets = data_manager.get_targets()
    progress = data_manager.get_progress()

    # Display max sets information
    st.subheader("Personal Bests (Max Sets)")
    max_cols = st.columns(3)
    for idx, exercise in enumerate(['pushups', 'situps', 'squats']):
        with max_cols[idx]:
            max_value = progress['max_sets'][exercise]
            target_value = targets['overall'][exercise]
            percentage = (max_value / target_value * 100) if target_value > 0 else 0
            st.metric(
                label=f"Max {exercise.capitalize()}",
                value=max_value,
                delta=f"{percentage:.1f}% of target"
            )

    # Add Calendar Heatmap
    st.subheader("Workout Consistency")
    calendar_fig = create_calendar_heatmap(exercise_data)
    st.plotly_chart(calendar_fig, use_container_width=True)

    # Create summary cards
    cards = create_summary_cards(progress, targets)

    # Display summary cards in columns
    timeframes = ['monthly', 'quarterly', 'yearly']
    for timeframe in timeframes:
        st.subheader(f"{timeframe.capitalize()} Progress")
        cols = st.columns(3)
        for idx, exercise in enumerate(['pushups', 'situps', 'squats']):
            with cols[idx]:
                st.metric(
                    label=exercise.capitalize(),
                    value=cards[timeframe][exercise]['current'],
                    delta=f"{cards[timeframe][exercise]['percentage']:.1f}% of target"
                )

    # Display charts
    figures = create_progress_charts(exercise_data, targets, progress)
    st.plotly_chart(figures['monthly'], use_container_width=True)
    st.plotly_chart(figures['timeline'], use_container_width=True)
    st.plotly_chart(figures['max_timeline'], use_container_width=True)

elif page == "History":
    st.header("Exercise History")

    exercise_data = data_manager.get_exercise_history()
    if exercise_data:
        df = pd.DataFrame(exercise_data)

        # Display sets details in an expandable section
        with st.expander("View Sets Details"):
            for record in exercise_data:
                st.write(f"Date: {record['date']}")
                cols = st.columns(3)
                with cols[0]:
                    st.write("Push-ups sets:", record['pushups_sets'])
                    st.write(f"Max: {record['pushups_max']}")
                with cols[1]:
                    st.write("Sit-ups sets:", record['situps_sets'])
                    st.write(f"Max: {record['situps_max']}")
                with cols[2]:
                    st.write("Squats sets:", record['squats_sets'])
                    st.write(f"Max: {record['squats_max']}")
                st.divider()

        # Display summary table
        summary_df = pd.DataFrame([{
            'date': record['date'],
            'pushups_max': record['pushups_max'],
            'situps_max': record['situps_max'],
            'squats_max': record['squats_max'],
            'pushups_total': record['pushups_total'],
            'situps_total': record['situps_total'],
            'squats_total': record['squats_total']
        } for record in exercise_data])

        st.dataframe(
            summary_df.sort_values('date', ascending=False),
            use_container_width=True
        )
    else:
        st.info("No exercise data recorded yet.")