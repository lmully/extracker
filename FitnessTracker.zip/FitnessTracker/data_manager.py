import os
from datetime import datetime, timedelta
import json
import random
from sqlalchemy import create_engine, Column, Integer, String, Date, Float, ARRAY, Boolean, ForeignKey
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, relationship

Base = declarative_base()

class Exercise(Base):
    __tablename__ = 'exercises'

    id = Column(Integer, primary_key=True)
    date = Column(Date, nullable=False)
    pushups_sets = Column(ARRAY(Integer), default=[])
    situps_sets = Column(ARRAY(Integer), default=[])
    squats_sets = Column(ARRAY(Integer), default=[])

class Target(Base):
    __tablename__ = 'targets'

    id = Column(Integer, primary_key=True)
    timeframe = Column(String, nullable=False)  # overall, monthly, quarterly, yearly
    exercise_type = Column(String, nullable=False)  # pushups, situps, squats
    target_value = Column(Integer, nullable=False)

class Challenge(Base):
    __tablename__ = 'challenges'

    id = Column(Integer, primary_key=True)
    start_date = Column(Date, nullable=False)
    end_date = Column(Date, nullable=False)
    challenge_type = Column(String, nullable=False)  # 'pushups', 'situps', 'squats', 'combined'
    target_value = Column(Integer, nullable=False)
    description = Column(String, nullable=False)
    completed = Column(Boolean, default=False)
    reward_points = Column(Integer, default=100)


class DataManager:
    def __init__(self):
        try:
            DATABASE_URL = os.environ['DATABASE_URL']
            self.engine = create_engine(DATABASE_URL)
            Base.metadata.create_all(self.engine)
            Session = sessionmaker(bind=self.engine)
            self.session = Session()
            self._initialize_data()
        except Exception as e:
            print(f"Database initialization error: {str(e)}")
            raise

    def _initialize_data(self):
        try:
            # Initialize default targets if none exist
            if not self.session.query(Target).first():
                default_targets = {
                    'overall': {'pushups': 100, 'situps': 100, 'squats': 100},
                    'monthly': {'pushups': 3000, 'situps': 3000, 'squats': 3000},
                    'quarterly': {'pushups': 9000, 'situps': 9000, 'squats': 9000},
                    'yearly': {'pushups': 36000, 'situps': 36000, 'squats': 36000}
                }

                for timeframe, exercises in default_targets.items():
                    for exercise_type, value in exercises.items():
                        target = Target(
                            timeframe=timeframe,
                            exercise_type=exercise_type,
                            target_value=value
                        )
                        self.session.add(target)

                self.session.commit()
        except Exception as e:
            print(f"Data initialization error: {str(e)}")
            self.session.rollback()
            raise

    def save_daily_exercise(self, pushups_sets, situps_sets, squats_sets):
        try:
            today = datetime.now().date()

            # Update if entry exists for today, otherwise create new
            exercise = self.session.query(Exercise).filter(Exercise.date == today).first()
            if exercise:
                exercise.pushups_sets = pushups_sets
                exercise.situps_sets = situps_sets
                exercise.squats_sets = squats_sets
            else:
                exercise = Exercise(
                    date=today,
                    pushups_sets=pushups_sets,
                    situps_sets=situps_sets,
                    squats_sets=squats_sets
                )
                self.session.add(exercise)

            self.session.commit()
            return True
        except Exception as e:
            print(f"Error saving exercise data: {str(e)}")
            self.session.rollback()
            return False

    def get_exercise_history(self):
        try:
            exercises = self.session.query(Exercise).order_by(Exercise.date).all()
            return [{
                'date': ex.date.strftime('%Y-%m-%d'),
                'pushups_sets': ex.pushups_sets,
                'situps_sets': ex.situps_sets,
                'squats_sets': ex.squats_sets,
                'pushups_max': max(ex.pushups_sets) if ex.pushups_sets else 0,
                'situps_max': max(ex.situps_sets) if ex.situps_sets else 0,
                'squats_max': max(ex.squats_sets) if ex.squats_sets else 0,
                'pushups_total': sum(ex.pushups_sets),
                'situps_total': sum(ex.situps_sets),
                'squats_total': sum(ex.squats_sets)
            } for ex in exercises]
        except Exception as e:
            print(f"Error retrieving exercise history: {str(e)}")
            return []

    def save_targets(self, targets):
        try:
            # Clear existing targets
            self.session.query(Target).delete()

            # Add new targets
            for timeframe, exercises in targets.items():
                for exercise_type, value in exercises.items():
                    target = Target(
                        timeframe=timeframe,
                        exercise_type=exercise_type,
                        target_value=value
                    )
                    self.session.add(target)

            self.session.commit()
            return True
        except Exception as e:
            print(f"Error saving targets: {str(e)}")
            self.session.rollback()
            return False

    def get_targets(self):
        try:
            targets = self.session.query(Target).all()
            result = {
                'overall': {},
                'monthly': {},
                'quarterly': {},
                'yearly': {}
            }

            for target in targets:
                result[target.timeframe][target.exercise_type] = target.target_value

            return result
        except Exception as e:
            print(f"Error retrieving targets: {str(e)}")
            return {
                'overall': {'pushups': 0, 'situps': 0, 'squats': 0},
                'monthly': {'pushups': 0, 'situps': 0, 'squats': 0},
                'quarterly': {'pushups': 0, 'situps': 0, 'squats': 0},
                'yearly': {'pushups': 0, 'situps': 0, 'squats': 0}
            }

    def get_progress(self):
        try:
            now = datetime.now()
            month_start = now.replace(day=1)
            quarter_start = now.replace(month=((now.month-1)//3)*3+1, day=1)
            year_start = now.replace(month=1, day=1)

            progress = {
                'monthly': {'pushups': 0, 'situps': 0, 'squats': 0},
                'quarterly': {'pushups': 0, 'situps': 0, 'squats': 0},
                'yearly': {'pushups': 0, 'situps': 0, 'squats': 0},
                'max_sets': {'pushups': 0, 'situps': 0, 'squats': 0}
            }

            exercises = self.session.query(Exercise).all()

            for ex in exercises:
                # Update max sets if current exercise has higher values
                progress['max_sets']['pushups'] = max(progress['max_sets']['pushups'], max(ex.pushups_sets) if ex.pushups_sets else 0)
                progress['max_sets']['situps'] = max(progress['max_sets']['situps'], max(ex.situps_sets) if ex.situps_sets else 0)
                progress['max_sets']['squats'] = max(progress['max_sets']['squats'], max(ex.squats_sets) if ex.squats_sets else 0)

                # Calculate totals for different timeframes
                if ex.date >= month_start.date():
                    progress['monthly']['pushups'] += sum(ex.pushups_sets)
                    progress['monthly']['situps'] += sum(ex.situps_sets)
                    progress['monthly']['squats'] += sum(ex.squats_sets)

                if ex.date >= quarter_start.date():
                    progress['quarterly']['pushups'] += sum(ex.pushups_sets)
                    progress['quarterly']['situps'] += sum(ex.situps_sets)
                    progress['quarterly']['squats'] += sum(ex.squats_sets)

                if ex.date >= year_start.date():
                    progress['yearly']['pushups'] += sum(ex.pushups_sets)
                    progress['yearly']['situps'] += sum(ex.situps_sets)
                    progress['yearly']['squats'] += sum(ex.squats_sets)

            return progress
        except Exception as e:
            print(f"Error calculating progress: {str(e)}")
            return {
                'monthly': {'pushups': 0, 'situps': 0, 'squats': 0},
                'quarterly': {'pushups': 0, 'situps': 0, 'squats': 0},
                'yearly': {'pushups': 0, 'situps': 0, 'squats': 0},
                'max_sets': {'pushups': 0, 'situps': 0, 'squats': 0}
            }

    def create_weekly_challenge(self):
        try:
            today = datetime.now().date()
            week_start = today - timedelta(days=today.weekday())
            week_end = week_start + timedelta(days=6)

            # Check if there's already an active challenge
            existing_challenge = self.session.query(Challenge).filter(
                Challenge.end_date >= today
            ).first()

            if existing_challenge:
                return existing_challenge

            # Generate a new challenge
            exercise_types = ['pushups', 'situps', 'squats', 'combined']
            challenge_type = random.choice(exercise_types)

            # Get user's recent performance
            recent_exercises = self.session.query(Exercise).filter(
                Exercise.date >= today - timedelta(days=30)
            ).all()

            if recent_exercises:
                # Calculate average daily totals
                total_days = len(recent_exercises)
                if challenge_type == 'pushups':
                    avg_daily = sum(sum(ex.pushups_sets) for ex in recent_exercises) / total_days
                    target = int(avg_daily * 1.2 * 7)  # 20% increase from average, for the week
                    description = f"Complete {target} push-ups this week"
                elif challenge_type == 'situps':
                    avg_daily = sum(sum(ex.situps_sets) for ex in recent_exercises) / total_days
                    target = int(avg_daily * 1.2 * 7)
                    description = f"Complete {target} sit-ups this week"
                elif challenge_type == 'squats':
                    avg_daily = sum(sum(ex.squats_sets) for ex in recent_exercises) / total_days
                    target = int(avg_daily * 1.2 * 7)
                    description = f"Complete {target} squats this week"
                else:  # combined
                    target = 300
                    description = "Complete a total of 300 combined exercises this week"
            else:
                # Default targets for new users
                if challenge_type == 'combined':
                    target = 150
                    description = "Complete a total of 150 combined exercises this week"
                else:
                    target = 100
                    description = f"Complete 100 {challenge_type} this week"

            new_challenge = Challenge(
                start_date=week_start,
                end_date=week_end,
                challenge_type=challenge_type,
                target_value=target,
                description=description
            )

            self.session.add(new_challenge)
            self.session.commit()
            return new_challenge

        except Exception as e:
            print(f"Error creating weekly challenge: {str(e)}")
            self.session.rollback()
            return None

    def get_active_challenge(self):
        try:
            today = datetime.now().date()
            return self.session.query(Challenge).filter(
                Challenge.end_date >= today
            ).first()
        except Exception as e:
            print(f"Error retrieving active challenge: {str(e)}")
            return None

    def check_challenge_completion(self):
        try:
            challenge = self.get_active_challenge()
            if not challenge or challenge.completed:
                return None

            # Get exercise data for the challenge period
            exercises = self.session.query(Exercise).filter(
                Exercise.date.between(challenge.start_date, challenge.end_date)
            ).all()

            total = 0
            if challenge.challenge_type == 'pushups':
                total = sum(sum(ex.pushups_sets) for ex in exercises)
            elif challenge.challenge_type == 'situps':
                total = sum(sum(ex.situps_sets) for ex in exercises)
            elif challenge.challenge_type == 'squats':
                total = sum(sum(ex.squats_sets) for ex in exercises)
            else:  # combined
                total = sum(
                    sum(ex.pushups_sets) + sum(ex.situps_sets) + sum(ex.squats_sets)
                    for ex in exercises
                )

            if total >= challenge.target_value:
                challenge.completed = True
                self.session.commit()
                return True

            return False

        except Exception as e:
            print(f"Error checking challenge completion: {str(e)}")
            return False